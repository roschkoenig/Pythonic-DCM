% Statistical Parametric Mapping
% Version 7771 (SPM12) 13-Jan-20
