% SPM Spectral Estimation Toolbox
%
