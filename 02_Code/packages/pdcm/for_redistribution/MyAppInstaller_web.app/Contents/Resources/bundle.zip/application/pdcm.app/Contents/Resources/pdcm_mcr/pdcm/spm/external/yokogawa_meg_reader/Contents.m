% Yokogawa MEG Reader toolbox for MATLAB
% Version 1.5.1 04-June-2018
