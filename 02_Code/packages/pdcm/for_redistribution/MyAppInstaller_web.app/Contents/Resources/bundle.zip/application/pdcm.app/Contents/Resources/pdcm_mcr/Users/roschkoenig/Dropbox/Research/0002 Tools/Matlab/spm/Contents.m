% Statistical Parametric Mapping
% Version 12.3 (SPM12) 20-Oct-2016
