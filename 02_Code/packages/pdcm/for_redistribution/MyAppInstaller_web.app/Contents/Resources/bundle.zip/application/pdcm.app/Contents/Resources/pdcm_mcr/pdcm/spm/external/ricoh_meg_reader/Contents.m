% RICOH MEG Reader toolbox for MATLAB
% Version 1.0.2 04-June-2018
