% Yokogawa MEG Reader toolbox for MATLAB
% Version 1.04.01 01-Nov-2011
