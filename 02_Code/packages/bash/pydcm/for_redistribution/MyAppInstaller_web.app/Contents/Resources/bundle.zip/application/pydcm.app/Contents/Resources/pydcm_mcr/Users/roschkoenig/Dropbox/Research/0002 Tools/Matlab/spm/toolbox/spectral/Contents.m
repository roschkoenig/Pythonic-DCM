% SPM Spectral Estimation Toolbox
%
